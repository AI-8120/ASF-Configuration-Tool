Configure the ASF Configuration Tool.exe into the ASF directory
ASF download https://github.com/JustArchiNET/ArchiSteamFarm/